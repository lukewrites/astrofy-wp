<?php
/**
 * Sidebar / Drawer Side Panel
 */
$profile_image = get_theme_mod( 'astrofy_profile_image', get_template_directory_uri() . '/assets/images/profile.webp' );
$github_url    = get_theme_mod( 'astrofy_github_url', '' );
$twitter_url   = get_theme_mod( 'astrofy_twitter_url', '' );
$linkedin_url  = get_theme_mod( 'astrofy_linkedin_url', '' );
$support_url   = get_theme_mod( 'astrofy_support_url', '' );
?>
<div class="drawer-side z-40">
    <label for="my-drawer" class="drawer-overlay"></label>
    <aside class="px-2 pt-2 h-auto min-h-full w-[19rem] bg-base-200 text-base-content flex flex-col">
        <div class="w-fit mx-auto mt-5 mb-6">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                <div class="avatar transition ease-in-out hover:scale-[102%] block m-auto">
                    <div class="w-[8.5rem]">
                        <img class="mask mask-circle" width="300" height="300" src="<?php echo esc_url( $profile_image ); ?>" alt="<?php esc_attr_e( 'Profile image', 'astrofy' ); ?>" />
                    </div>
                </div>
            </a>
        </div>

        <?php
        if ( has_nav_menu( 'sidebar-menu' ) ) {
            wp_nav_menu( array(
                'theme_location' => 'sidebar-menu',
                'container'      => false,
                'menu_class'     => 'menu grow shrink menu-md overflow-y-auto',
                'walker'         => new Astrofy_Sidebar_Walker(),
                'fallback_cb'    => false,
            ) );
        } else {
            // Default menu matching Astro source
            ?>
            <ul class="menu grow shrink menu-md overflow-y-auto">
                <li><a class="py-3 text-base<?php if ( is_front_page() ) echo ' bg-base-300'; ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
                <li><a class="py-3 text-base<?php if ( is_page( 'projects' ) ) echo ' bg-base-300'; ?>" href="<?php echo esc_url( home_url( '/projects/' ) ); ?>">Projects</a></li>
                <li><a class="py-3 text-base<?php if ( is_page( 'services' ) ) echo ' bg-base-300'; ?>" href="<?php echo esc_url( home_url( '/services/' ) ); ?>">Services</a></li>
                <li><a class="py-3 text-base<?php if ( is_post_type_archive( 'store_item' ) || is_singular( 'store_item' ) ) echo ' bg-base-300'; ?>" href="<?php echo esc_url( get_post_type_archive_link( 'store_item' ) ); ?>">Store</a></li>
                <li><a class="py-3 text-base<?php if ( is_home() || is_singular( 'post' ) || is_tag() || ( is_archive() && ! is_post_type_archive() ) ) echo ' bg-base-300'; ?>" href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ?: home_url( '/blog/' ) ); ?>">Blog</a></li>
                <li><a class="py-3 text-base<?php if ( is_page( 'cv' ) ) echo ' bg-base-300'; ?>" href="<?php echo esc_url( home_url( '/cv/' ) ); ?>">CV</a></li>
                <?php
                $contact_email = get_theme_mod( 'astrofy_contact_email', '' );
                if ( $contact_email ) : ?>
                <li><a class="py-3 text-base" href="mailto:<?php echo esc_attr( $contact_email ); ?>" target="_blank" referrerpolicy="no-referrer-when-downgrade">Contact</a></li>
                <?php endif; ?>
            </ul>
            <?php
        }
        ?>

        <div class="block sticky pointer-events-none bottom-10 bg-base-200 justify-center h-12 [mask-image:linear-gradient(transparent,#000000)]"></div>

        <div class="social-icons px-4 pb-5 pt-1 flex self-center justify-center sticky bottom-0 bg-base-200">
            <?php if ( $support_url ) : ?>
            <a href="<?php echo esc_url( $support_url ); ?>" target="_blank" class="mx-3" aria-label="Support my work" title="Support my work">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: currentColor;transform: ;msFilter:;"><path fill-rule="evenodd" clip-rule="evenodd" d="M5 2h2v3H5zm4 0h2v3H9zm4 0h2v3h-2zm6 7h-2V7H3v11c0 1.654 1.346 3 3 3h8c1.654 0 3-1.346 3-3h2c1.103 0 2-.897 2-2v-5c0-1.103-.897-2-2-2zm-4 9a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V9h10v9zm2-2v-5h2l.002 5H17z"></path></svg>
            </a>
            <?php endif; ?>

            <?php if ( $github_url ) : ?>
            <a href="<?php echo esc_url( $github_url ); ?>" target="_blank" class="mx-3" aria-label="Github" title="Github">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: currentColor;transform: ;msFilter:;"><path fill-rule="evenodd" clip-rule="evenodd" d="M12.026 2c-5.509 0-9.974 4.465-9.974 9.974 0 4.406 2.857 8.145 6.821 9.465.499.09.679-.217.679-.481 0-.237-.008-.865-.011-1.696-2.775.602-3.361-1.338-3.361-1.338-.452-1.152-1.107-1.459-1.107-1.459-.905-.619.069-.605.069-.605 1.002.07 1.527 1.028 1.527 1.028.89 1.524 2.336 1.084 2.902.829.091-.645.351-1.085.635-1.334-2.214-.251-4.542-1.107-4.542-4.93 0-1.087.389-1.979 1.024-2.675-.101-.253-.446-1.268.099-2.64 0 0 .837-.269 2.742 1.021a9.582 9.582 0 0 1 2.496-.336 9.554 9.554 0 0 1 2.496.336c1.906-1.291 2.742-1.021 2.742-1.021.545 1.372.203 2.387.099 2.64.64.696 1.024 1.587 1.024 2.675 0 3.833-2.33 4.675-4.552 4.922.355.308.675.916.675 1.846 0 1.334-.012 2.41-.012 2.737 0 .267.178.577.687.479C19.146 20.115 22 16.379 22 11.974 22 6.465 17.535 2 12.026 2z"></path></svg>
            </a>
            <?php endif; ?>

            <?php if ( $twitter_url ) : ?>
            <a href="<?php echo esc_url( $twitter_url ); ?>" target="_blank" class="mx-3" aria-label="Twitter" title="Twitter">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: currentColor;transform: ;msFilter:;"><path d="M19.633 7.997c.013.175.013.349.013.523 0 5.325-4.053 11.461-11.46 11.461-2.282 0-4.402-.661-6.186-1.809.324.037.636.05.973.05a8.07 8.07 0 0 0 5.001-1.721 4.036 4.036 0 0 1-3.767-2.793c.249.037.499.062.761.062.361 0 .724-.05 1.061-.137a4.027 4.027 0 0 1-3.23-3.953v-.05c.537.299 1.16.486 1.82.511a4.022 4.022 0 0 1-1.796-3.354c0-.748.199-1.434.548-2.032a11.457 11.457 0 0 0 8.306 4.215c-.062-.3-.1-.611-.1-.923a4.026 4.026 0 0 1 4.028-4.028c1.16 0 2.207.486 2.943 1.272a7.957 7.957 0 0 0 2.556-.973 4.02 4.02 0 0 1-1.771 2.22 8.073 8.073 0 0 0 2.319-.624 8.645 8.645 0 0 1-2.019 2.083z"></path></svg>
            </a>
            <?php endif; ?>

            <?php if ( $linkedin_url ) : ?>
            <a href="<?php echo esc_url( $linkedin_url ); ?>" target="_blank" class="mx-3" aria-label="Linkedin" title="Linkedin">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: currentColor;transform: ;msFilter:;"><circle cx="4.983" cy="5.009" r="2.188"></circle><path d="M9.237 8.855v12.139h3.769v-6.003c0-1.584.298-3.118 2.262-3.118 1.937 0 1.961 1.811 1.961 3.218v5.904H21v-6.657c0-3.27-.704-5.783-4.526-5.783-1.835 0-3.065 1.007-3.568 1.96h-.051v-1.66H9.237zm-6.142 0H6.87v12.139H3.095z"></path></svg>
            </a>
            <?php endif; ?>

            <a href="<?php echo esc_url( get_bloginfo( 'rss2_url' ) ); ?>" target="_blank" class="mx-3" aria-label="RSS Feed" title="RSS Feed">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: currentColor;transform: ;msFilter:;"><path d="M19 20.001C19 11.729 12.271 5 4 5v2c7.168 0 13 5.832 13 13.001h2z"></path><path d="M12 20.001h2C14 14.486 9.514 10 4 10v2c4.411 0 8 3.589 8 8.001z"></path><circle cx="6" cy="18" r="2"></circle></svg>
            </a>
        </div>
    </aside>
</div>
