# Keeping astrofy-wp in Sync with Upstream Astrofy

## Context

The `astrofy-wp` WordPress theme was converted from `manuelernestog/astrofy` (an Astro template). The WP theme now lives in its own standalone repo. We need a workflow to detect upstream changes in the Astro repo and port relevant ones to the WP theme, since the two codebases use completely different frameworks and can't be auto-merged.

## Color Schemes — Status

All 32 DaisyUI themes are already included and working:
- `inc/customizer.php` — dropdown with all themes (lofi, dark, cupcake, synthwave, dracula, nord, etc.)
- `header.php` — applies the selection via `data-theme` attribute on `<html>`
- `global.css` — compiled with `themes: true` so all theme CSS is bundled

No changes needed here.

## Recommended Sync Workflow

### 1. Add upstream as a remote in the astrofy-wp repo

```bash
cd astrofy-wp
git remote add upstream https://github.com/manuelernestog/astrofy.git
git fetch upstream
```

This lets you pull upstream changes without cloning a separate repo.

### 2. Periodic check for upstream changes

Run this to see what changed since your last sync:

```bash
git fetch upstream
git log upstream/main --oneline --since="2026-03-17"   # or since last sync date
```

Or diff specific files you care about:

```bash
git diff upstream/main -- src/components/ src/layouts/ src/pages/ tailwind.config.cjs src/styles/
```

### 3. Review and manually port changes

Since Astro → PHP is a structural conversion (not a 1:1 file mapping), changes can't be cherry-picked automatically. Instead:

| Upstream file changed | WP file(s) to update |
|---|---|
| `src/layouts/BaseLayout.astro` | `header.php`, `footer.php` |
| `src/components/SideBar.astro` / `SideBarMenu.astro` / `SideBarFooter.astro` | `sidebar.php` |
| `src/components/HorizontalCard.astro` | `inc/template-tags.php` → `astrofy_horizontal_card()` |
| `src/components/HorizontalShopItem.astro` | `inc/template-tags.php` → `astrofy_horizontal_shop_item()` |
| `src/components/cv/TimeLine.astro` | `inc/template-tags.php` → `astrofy_timeline_element()` |
| `src/pages/index.astro` | `front-page.php` |
| `src/pages/blog/[...page].astro` | `archive.php`, `index.php` |
| `src/pages/blog/[slug].astro` + `PostLayout.astro` | `single.php` |
| `src/pages/store/*` + `StoreItemLayout.astro` | `archive-store_item.php`, `single-store_item.php` |
| `src/pages/cv.astro` | `page-cv.php` |
| `src/pages/404.astro` | `404.php` |
| `src/content/config.ts` | `inc/meta-boxes.php` (if new fields added) |
| `tailwind.config.cjs` | `tailwind.config.js` + rebuild CSS |
| `src/styles/global.css` | `assets/css/tailwind-src.css` + rebuild CSS |
| `public/*` (images) | `assets/images/` |

### 4. After porting changes, rebuild CSS

```bash
cd astrofy-wp
node ./node_modules/.bin/tailwindcss -i ./assets/css/tailwind-src.css -o ./assets/css/global.css --minify
```

### 5. Track sync state

Keep a simple note in the repo (e.g. in a `SYNC.md` or a git tag):

```bash
# After porting upstream changes:
git tag synced/upstream-$(git rev-parse --short upstream/main)
```

This way you always know which upstream commit you last synced to.

### Alternative: GitHub Actions (automated detection)

If you want to be notified when upstream changes, add a scheduled GitHub Action to the astrofy-wp repo:

```yaml
# .github/workflows/check-upstream.yml
name: Check upstream for changes
on:
  schedule:
    - cron: '0 9 * * 1'  # Every Monday at 9am
  workflow_dispatch:

jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - run: git remote add upstream https://github.com/manuelernestog/astrofy.git
      - run: git fetch upstream
      - name: Check for new commits
        run: |
          LAST_TAG=$(git tag -l 'synced/upstream-*' --sort=-creatordate | head -1)
          if [ -z "$LAST_TAG" ]; then
            echo "No sync tags found — run initial sync"
            exit 0
          fi
          LAST_HASH=${LAST_TAG#synced/upstream-}
          NEW_COMMITS=$(git log --oneline ${LAST_HASH}..upstream/main -- src/ tailwind.config.cjs public/)
          if [ -n "$NEW_COMMITS" ]; then
            echo "::warning::Upstream has new changes to port:"
            echo "$NEW_COMMITS"
          else
            echo "Up to date with upstream"
          fi
```

## Verification

- Run `git remote -v` to confirm upstream is configured
- Run `git fetch upstream && git log upstream/main --oneline -5` to see latest upstream commits
- After porting, test in Docker: `docker start local-wordpress` and visit http://localhost:8080
