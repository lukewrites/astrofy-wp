# astrofy-wp

A WordPress version of the excellent [Astrofy](https://github.com/manuelernestog/astrofy) theme originally created by Manuel Ernesto Garcia. This theme is a one-shot conversion created by Claude Code WordPress.

## Features
- Personal portfolio layout
- Modern design powered by Tailwind CSS and DaisyUI
- WordPress Customizer support for easy updates to the hero section and more

## Installation
1. Download the latest release from the [Releases](https://github.com/lukewrites/astrofy-wp/releases) page.
2. Go to your WordPress Dashboard > Appearance > Themes.
3. Click "Add New" and "Upload Theme".
4. Upload the downloaded `.zip` file and activate the theme.

## Development
To modify the theme styles:
1. Make sure you have Node.js installed.
2. Run `npm install` to grab the necessary dependencies.
3. Run `npm run watch:css` to build the CSS and watch for changes in the `tailwind-src.css` and template files.

## Credits & License
- Originally designed and developed as an Astro template by [Manuel Ernesto Garcia](https://manuelernestog.github.io).
- Ported to WordPress by Luke Petschauer poking at Claude Code.

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.